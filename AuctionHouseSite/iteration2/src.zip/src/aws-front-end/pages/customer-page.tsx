'use client'
import React, { useEffect, useState } from 'react';
import './customer-page.css';
import axios from 'axios';

const instance = axios.create({
    baseURL: 'https://0sy7wxlvx0.execute-api.us-east-2.amazonaws.com/AuctionHouse'
})


export default function Home() {
    //RENDER

    const [customerItems, setCustomerItems] = useState([]);

    const viewItemCustomer = (e: any) => {
        const username = "customer"
        const data = { username };

        console.log("sending data...")
        console.log(data)
        instance.post("/viewItemCustomer", data).then(function (response) {
            //do something here
            if (400 === response.data.statusCode) {
                alert(response.data.error);
            }
            else if (200 === response.data.statusCode) {
                // alert("items reviewed")
                setCustomerItems(response.data.data);
            }
        }).catch(function (error) {
            alert("Failed")
            //add errors
        })
    }

    const getHighestBidder = (bids: any) => {
        if (!bids) {
            return ""; // Handle null or undefined bids
        }
        try {
            bids = JSON.parse(bids);

            if (!Array.isArray(bids) || bids.length === 0) {
                return ""; // Handle non-array or empty array cases
            }

            const highestBid = bids.reduce((max: { amount: number }, bid: { amount: number }) => {
                return Number(bid.amount) > Number(max.amount) ? bid : max;
            });
            return highestBid.username || ""; // Ensure username is returned or an empty string
        } catch (error) {
            return ""; // Handle JSON parsing errors
        }
    };

    return (
        <main className="customerMain">
            <div id="customerUsername" className="customerUsername">
                {"customer"}
            </div>

            <div className="searchBoxes">
                <div className="itemNameSearchBox">
                    <label>Item name: </label>
                    <input className="itemNameInput" type="text" placeholder="item name"></input>
                    <button className="itemNameSearchButton">Search</button>
                </div>

                <div className="itemDescriptionSearchBox">
                    <label>Item description: </label>
                    <input className="itemDescriptionInput" type="text" placeholder="item description"></input>
                    <button className="itemDescriptionSearchButton">Search</button>
                </div>

                <div className="itemPriceSearchBox">
                    <label>Item price: </label>
                    <input className="itemPriceInput" type="text" placeholder="item price"></input>
                    <button className="itemPriceSearchButton">Search</button>
                </div>

                <div className="itemStartDateSearchBox">
                    <label>Item start date: </label>
                    <input className="itemStartDateInput" type="date" placeholder="item start date"></input>
                    <button className="itemStartDateSearchButton">Search</button>
                </div>

                <div className="itemEndDateSearchBox">
                    <label>Item end date: </label>
                    <input className="itemEndDateInput" type="date" placeholder="item end date"></input>
                    <button className="itemEndDateSearchButton">Search</button>
                </div>
            </div>



            <div className="customerItems">
                <button className="reviewItems" onClick={(e) => viewItemCustomer(e)}>{"View Items"}</button>
                <label>Items: </label>

            </div>

            <div className="itemTable">
                {customerItems && customerItems.length > 0 ? (
                    <table className="items">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Item Price</th>
                                <th>Item Description</th>
                                <th>Item Image</th>
                                <th>Highest Bid/Bidder</th>
                                <th>Bidding History</th>
                                <th>End Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {customerItems.map((item, index) => (
                                <><tr key={index}>
                                    <td>{item.itemName}</td>
                                    <td>{item.price}</td>
                                    <td>{item.description}</td>
                                    <td><img className="itemImage" src={item.imageUrl} /></td>
                                    <td>{getHighestBidder(item.bids)}</td>
                                    <td>
                                        <table className="biddingHistory">
                                            <tbody>
                                                <tr>
                                                    <td>{item.bids}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                    <td>{item.endDate}</td>
                                </tr><tr>
                                        <label>__</label>
                                    </tr></>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <p>No items to display</p>
                )}
            </div>


            <div className="sorting">
                <button className="sortingButton">Search Recently Sold</button>
                <label className="sortLabel">Sort Recently Sold</label>
                <button className="sortingButton"> Name </button>
                <button className="sortingButton"> Price </button>
                <button className="sortingButton"> Start </button>
                <button className="sortingButton"> End </button>
            </div>


        </main >
    );
}