'use client'
import React from 'react'
import './customer-page.css';

export default function Home() {
    //RENDER
    return (
        <main className="customerMain">

            <div id="customerUsername" className="customerUsername">
                Customer Username Goes Here
            </div>

            <div className="itemNameSearchBox">
                <label>Item name: </label>
                <input className="itemNameInput" type="text" placeholder="item name"></input>
                <button className="itemNameSearchButton">Search</button>
            </div>

            <div className="itemDescriptionSearchBox">
                <label>Item description: </label>
                <input className="itemDescriptionInput" type="text" placeholder="item description"></input>
                <button className="itemDescriptionSearchButton">Search</button>
            </div>

            <div className="itemPriceSearchBox">
                <label>Item price: </label>
                <input className="itemPriceInput" type="text" placeholder="item price"></input>
                <button className="itemPriceSearchButton">Search</button>
            </div>

            <div className="itemStartDateSearchBox">
                <label>Item start date: </label>
                <input className="itemStartDateInput" type="date" placeholder="item start date"></input>
                <button className="itemStartDateSearchButton">Search</button>
            </div>

            <div className="itemEndDateSearchBox">
                <label>Item end date: </label>
                <input className="itemEndDateInput" type="date" placeholder="item end date"></input>
                <button className="itemEndDateSearchButton">Search</button>
            </div>



            <div className="customerItems">
                <label>Items: </label>
            </div>

            <div className="sorting">
                <label className="sortLabel">Sort Recently Sold</label>
                <button className="sortingButton"> Name </button>
                <button className="sortingButton"> Price </button>
                <button className="sortingButton"> Start </button>
                <button className="sortingButton"> End </button>
            </div>

            <div className="itemCard">
                    <label className="itemName">Item 1</label>
                    <img className="itemImage" src="https://play-lh.googleusercontent.com/27O5tpaYE82W6m30rJ_MX3-UvshlDM6O8oXDxb6GseYW2T7P8UNT19727MGmz-0q3w"></img>
                    <label className="itemPrice">Price / Highest bid / bidder</label>
                    <label className="itemDescription">description</label>
            </div>

        </main >
    );
}
