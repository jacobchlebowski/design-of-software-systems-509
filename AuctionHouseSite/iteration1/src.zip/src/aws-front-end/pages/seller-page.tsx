'use client';
import React, { useEffect, useState } from 'react';
import './seller-page.css';
import axios from 'axios';

const instance = axios.create({
  baseURL: 'https://0sy7wxlvx0.execute-api.us-east-2.amazonaws.com/AuctionHouse'
});



export default function SellerPage() {
  const [sellerItems, setSellerItems] = useState([]);

  
  //GRAB SELLER USERNAME FROM URL
  const [username, setSellerUsername] = useState<string>("");
  useEffect(() => {
      const params = new URLSearchParams(window.location.search);
      const username = params.get("username");
      if (username) {
          setSellerUsername(username);
      }
  }, []);

  //handleAddItem
  const handleAddItem = () => {
    const itemName = (document.querySelector('.addItem-itemNameInput') as HTMLInputElement).value;
    const imageUrl = (document.querySelector('.addItem-uploadImageInput') as HTMLInputElement).value;
    const description = (document.querySelector('.addItem-descriptionInput') as HTMLInputElement).value;
    const price = (document.querySelector('.addItem-initialPriceInput') as HTMLInputElement).value;
    const startDate = (document.querySelector('.addItem-startDateInput') as HTMLInputElement).value;
    const endDate = (document.querySelector('.addItem-endDateInput') as HTMLInputElement).value;
    const sellerUsername = document.getElementById('sellerUsername')?.innerText;

    const data = { itemName, imageUrl, description, price, startDate, endDate, sellerUsername };
    instance.post('/addItemSeller', data)
      .then(response => {
        if (response.data.statusCode === 200) {
          alert('Item successfully added');
          reviewItems("");
        } else {
          alert(response.data.error);
        }
      })
      .catch(() => alert('Failed to add item.'));
  };

  //handleRemoveItem
  const handleRemoveItem = (itemId: any) => {
    const data = { itemId }
    instance.post('/removeInactiveItemSeller', data)
      .then(response => {
        if (response.data.statusCode === 200) {
          alert('Inactive item successfully removed');
          reviewItems("");
        } else {
          alert(response.data.error);
        }
      })
      .catch(() => alert('Failed to remove inactive item.'));
  };

  //handleEditItem
  const handleEditItem = () => {
    const itemID = (document.querySelector('.editItem-itemID') as HTMLInputElement).value;
    const imageUrl = (document.querySelector('.editItem-uploadImageInput') as HTMLInputElement).value;
    const itemName = (document.querySelector('.editItem-itemNameInput') as HTMLInputElement).value;
    const description = (document.querySelector('.editItem-descriptionInput') as HTMLInputElement).value;
    const price = (document.querySelector('.editItem-initialPriceInput') as HTMLInputElement).value;
    const startDate = (document.querySelector('.editItem-startDateInput') as HTMLInputElement).value;
    const endDate = (document.querySelector('.editItem-endDateInput') as HTMLInputElement).value;
    const sellerUsername = document.getElementById('sellerUsername')?.innerText;

    const data = { itemID, imageUrl, itemName, description, price, startDate, endDate, sellerUsername };
    instance.post('/editItemSeller', data)
      .then(response => {
        if (response.data.statusCode === 200) {
          alert('Item successfully edited');
          reviewItems("");
        } else {
          alert(response.data.error);
        }
      })
      .catch(() => alert('Failed to edit item.'));
  };

  const closeSellerAccount = (e: any) => {
    const sellerUsername = (document.getElementById("sellerUsername")).innerText;

    let data = { sellerUsername };

    console.log("Sending data:", data);
    instance.post("/closeAccountSeller", data).then(function (response) {
      //do something here
      if (400 === response.data.statusCode) {
        alert(response.data.error);
      }
      else if (200 === response.data.statusCode) {
        // alert(response.data.error);
        alert("Account successfully closed")
        // window.location.href = 'http://localhost:3000/login-page';
        window.location.href = `https://auctionhouse24.s3.us-east-2.amazonaws.com/login-page.html`;
      }
    }).catch(function (error) {
      alert("Failed")
      //add errors
    })
  }

  const reviewItems = (e: any) => {
    const sellerUsername = (document.getElementById("sellerUsername")).innerText;
    const data = { sellerUsername };

    instance.post("/reviewItems", data).then(function (response) {
      //do something here
      console.log(response)
      if (400 === response.data.statusCode) {
        alert(response.data.error);
      }
      else if (200 === response.data.statusCode) {
        // alert("items reviewed")
        console.log(response.data.data)
        setSellerItems(response.data.data);
      }
    }).catch(function (error) {
      alert("Failed")
      //add errors
    })
  }

  return (
    <main className="sellerMain">
      <div className="sellerUsername" id="sellerUsername">
        {username}
      </div>

      <div className="addItemForm">
        <label>Upload Image:</label>
        <input className="addItem-uploadImageInput" type="text" placeholder="Image URL" />

        <label>Item Name:</label>
        <input className="addItem-itemNameInput" type="text" placeholder="Item Name" />

        <label>Description:</label>
        <input className="addItem-descriptionInput" type="text" placeholder="Description" />

        <label>Initial Price:</label>
        <input className="addItem-initialPriceInput" type="text" placeholder="Initial Price" />

        <label>Start Date:</label>
        <input className="addItem-startDateInput" type="date" />

        <label>End Date:</label>
        <input className="addItem-endDateInput" type="date" />

        <button className="addItemButton" onClick={handleAddItem}>Add Item</button>
      </div>

      <div className="editItemForm">
        <div>
          <label>{"REQUIRED - Item ID: "}</label>
          <input className="editItem-itemID" type="text" placeholder="item to edit id" required></input>
        </div>
        <div>
          <label>{"Upload image: "}</label>
          <input className="editItem-uploadImageInput" type="text" placeholder="image url"></input>
        </div>
        <div>
          <label>{"Item Name: "}</label>
          <input className="editItem-itemNameInput" type="text" placeholder="item name"></input>
        </div>
        <div>
          <label>{"Description: "}</label>
          <input className="editItem-descriptionInput" type="text" placeholder="description"></input>
        </div>
        <div>
          <label>{"Initial Price: "}</label>
          <input className="editItem-initialPriceInput" type="text" placeholder="initial price"></input>
        </div>
        <div>
          <label>{"Start Date: "}</label>
          <input className="editItem-startDateInput" type="date" placeholder="start date"></input>
        </div>
        <div>
          <label>{"End Date: "}</label>
          <input className="editItem-endDateInput" type="date" placeholder="end date"></input>
        </div>
        <div className='editItemButtonDiv'>
          <button className="editItemButton" onClick={handleEditItem}>{"Edit item"}</button>
        </div>
      </div>


      <div className="sellerBalance">
        Seller Balance: $1000
        <button className="closeAccountButton" onClick={closeSellerAccount}>Close Account</button>
      </div>

      <div className="sellerItems">
        <button className="reviewItems" onClick={(e) => reviewItems(e)}>{"Review Items"}</button>
        <label>Items: </label>

      </div>

      <div className="itemTable">
        {sellerItems && sellerItems.length > 0 ? (
          <table className="items">
            <thead>
              <tr>
                <th>Item Name</th>
                <th>Item Price</th>
                <th>Item Image</th>
                <th>Item Status</th>
                <th>Item ID</th>
                <th>Item Description</th>
                <th>Fulfill Item</th>
                <th>Remove Item</th>
                <th>Archive Item</th>
                <th>Publish Item</th>
                <th>Unpublish Item</th>
                <th>Request Unfreeze</th>
              </tr>
            </thead>
            <tbody>
              {sellerItems.map((item, index) => (
                <tr key={index}>
                  <td>{item.itemName}</td>
                  <td>{item.price}</td>
                  <td><img src={String(item.imageUrl) || "https://play-lh.googleusercontent.com/27O5tpaYE82W6m30rJ_MX3-UvshlDM6O8oXDxb6GseYW2T7P8UNT19727MGmz-0q3w"} className="itemImage" /></td>
                  <td>{item.isActive ? "Inactive" : "Active"}</td>
                  <td>{item.id}</td>
                  <td>{item.description}</td>
                  <td><button>Fulfill Item</button></td>
                  <td><button onClick={() => handleRemoveItem(item.id)} disabled={!item.isActive}>Remove Item</button></td>
                  <td><button>Archive Item</button></td>
                  <td><button>Publish Item</button></td>
                  <td><button>Unpublish Item</button></td>
                  <td><button>Request Unfreeze</button></td>



                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No items to display</p>
        )}
      </div>


    </main >
  );
}