'use client'
import React, { useState } from 'react';
import './admin-page.css';


interface Item {
    name: string;
    activeAction: string;
  }

export default function Home() {
    const [firstValue, setFirstValue] = useState('');
    const [secondValue, setSecondValue] = useState('');
    const [selectedOption, setSelectedOption] = useState('');

    const [items, setItems] = useState<Item[]>([
        { name: 'Item 1', activeAction: '' },
        { name: 'Item 2', activeAction: '' },
        { name: 'Item 3', activeAction: '' },
        { name: 'Item 4', activeAction: '' },
      ]);
    
      const [reportContent, setReportContent] = useState<string>('');
      const [funds, setFunds] = useState<number>(100);
    
      const handleClick = (action: string, index: number): void => {
        setItems((prevItems) =>
          prevItems.map((item, i) =>
            i === index ? { ...item, activeAction: action } : item
          )
        );
      };
    
      const generateReport = () => {
        setReportContent('Sample Auction Report');
      };
    
      const generateForensicsReport = () => {
        setReportContent('Sample Forensics Report');
      };
    
      const setAuctionFunds = () => {
        setFunds(100);
      };
    
      return (
        <div className="page-container">
          <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            <div style={{ flex: 1, display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <div className="text-div">
                  Admin Username
                </div>
                <div className="button-container">
                  {items.map((item, index) => (
                    <div key={index} className="item-row">
                      <span className="item-name">{item.name}</span>
                      {['Freeze', 'Unfreeze'].map((action) => (
                        <button
                          key={action}
                          className="button"
                          onClick={() => handleClick(action, index)}
                          style={{
                            backgroundColor: item.activeAction === action ? '#d0d0d0' : '#e0e0e0',
                          }}
                        >
                          {action}
                        </button>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
              <div className="report-container">
                <div className="text-div">
                  Auction House Funds: ${funds}
                </div>
                <div className="report-div">
                  <div className="report-title">Report</div>
                  <div className="report-content">{reportContent}</div>
                </div>
              </div>
            </div>
            <div className="bottom-buttons">
              <button className="button" onClick={generateReport}>
                Generate Report
              </button>
              <button className="button" onClick={generateForensicsReport}>
                Generate Forensics Report
              </button>
            </div>
          </div>
        </div>
      );
    }