'use client'
import React, { useEffect, useState } from 'react';
import './buyer-page.css';
import axios from 'axios';

const instance = axios.create({
    baseURL: 'https://0sy7wxlvx0.execute-api.us-east-2.amazonaws.com/AuctionHouse'
})


export default function Home() {
    //RENDER

    //GRAB BUYERUSERNAME FROM URL
    const [username, setBuyerUsername] = useState<string>("");
    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const username = params.get("username");
        if (username) {
            setBuyerUsername(username);
        }
    }, []);


    const closeBuyerAccount = (e: any) => {
        const buyerUsername = (document.getElementById("buyerUsername")).innerText;

        let data = { buyerUsername };

        console.log("Sending data:", data);
        instance.post("/closeAccountBuyer", data).then(function (response) {
            //do something here
            if (400 === response.data.statusCode) {
                alert(response.data.error);
            }
            else if (200 === response.data.statusCode) {
                alert("Account successfully closed")
                // window.location.href = 'http://localhost:3000/login-page';
                window.location.href = `https://auctionhouse24.s3.us-east-2.amazonaws.com/login-page.html`;
            }
        }).catch(function (error) {
            alert("Failed")
            //add errors
        })
    }

    return (
        <main className="buyerMain">

            <div id="buyerUsername" className="buyerUsername">
                {username}
            </div>

            <div id="buyerBalance" className="buyerBalance">
                Buyer balance goes here
            </div>

            <div className="addBalance">
                <label>Add to Balance: </label>
                <button>Add funds</button>
                <input className="addFunds" type="text" placeholder="$"></input>
            </div>

            <div className="buyerItems">
                <label>Items: </label>
            </div>

            <div className="sorting">
                <button className="sortingButton">Search Recently Sold</button>
                <button className="sortingButton">Review My Active Bids</button>
                <button className="sortingButton">Review Purchases</button>
                <label className="sortLabel">Sort Recently Sold</label>
                <button className="sortingButton"> Name </button>
                <button className="sortingButton"> Price </button>
                <button className="sortingButton"> Start </button>
                <button className="sortingButton"> End </button>
            </div>

            <div className="closeAccount">
                <button className="closeAccountButton" onClick={(e) => closeBuyerAccount(e)}>Close Account</button>
            </div>

            <div className="itemCard">
                <label className="itemName">Item 1</label>
                <img className="itemImage" src="https://play-lh.googleusercontent.com/27O5tpaYE82W6m30rJ_MX3-UvshlDM6O8oXDxb6GseYW2T7P8UNT19727MGmz-0q3w"></img>
                <label className="itemPrice">Price / Highest bid / bidder</label>
                <label className="itemDescription">description</label>
                <button className="placeBid">Place Bid</button>
                <input className="bid" type="text" placeholder="$"></input>
                <label className="biddingHistoryLabel">Bidding History</label>
                <table className="biddingHistory">
                    <tbody>
                        <tr>
                            <td>bidders here...</td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </main >
    );
}