import mysql from 'mysql';
import config from './config.json' assert { type: 'json' };

var pool = mysql.createPool({
  host: config.host,
  user: config.user,
  password: config.password,
  database: config.database
});

export const handler = async (event) => {
  // TODO implement
  context.callbackWaitsForEmptyEventLoop = false;

  let response = {
    headers: {
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Origin": "*", // Allow from anywhere
      "Access-Control-Allow-Methods": "POST" // Allow POST request
    }
  };

  let info = event

  let loginBuyer = (username, password) => {
    return new Promise((resolve, reject) => {
      pool.query("SELECT * FROM Users WHERE username=? AND password=?", [username,password], (error,rows) => {
        if (error) {return reject(error);}
        if ((rows) && (rows.length >= 1)) {
          return resolve(200);
        }
        else {
          return resolve(400);
        }
      });
    });
  }
  
  try {
    if (!info.username) {
      response.statusCode = 400;
      response.error = "Username not provided";
      return response;
    }
    if (!info.password) {
      response.statusCode = 400;
      response.error = "Password not provided";
      return response;
    }
    let status;
    status = await loginBuyer(info.username, info.password);
    if (status === 200) {
      response.statusCode = 200;
      response.error = "Login Successful";
      return response;
    }
    else{
      response.statusCode = 400;
      response.error = "Database Errror";
      return response;
    }
  }
    catch (error) {
      console.log("ERROR: " + error);
      response.statusCode = 400;
      response.error = error;
      return response;
    }
};
